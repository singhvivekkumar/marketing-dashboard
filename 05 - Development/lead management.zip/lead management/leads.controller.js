import pool from '../config/database.js';

// ============================================================================
// LEADS CONTROLLER
// ============================================================================

export const createLead = async (req, res) => {
  const client = await pool.connect();
  try {
    const {
      customerId,
      leaderOwnerId,
      tenderName,
      tenderReferenceNo,
      tenderType,
      documentType,
      portalName,
      civilDefence,
      businessDomain,
      leadSubtype,
      soleConsortium,
      emdValue,
      emdExempted,
      emdMode,
      tenderDated,
      lastSubmissionDate,
      submissionMode,
      estimatedValueCr,
      winProbabilityPct,
      strategicImportance,
      internalNotes,
    } = req.body;

    // Validate required fields
    if (!tenderName || !tenderType || !documentType || !estimatedValueCr) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    const query = `
      INSERT INTO tenders (
        customer_id,
        lead_owner_id,
        tender_name,
        tender_reference_no,
        tender_type,
        document_type,
        portal_name,
        civil_defence,
        business_domain,
        lead_subtype,
        sole_consortium,
        emd_value,
        emd_exempted,
        emd_mode,
        tender_dated,
        last_submission_date,
        submission_mode,
        estimated_value_cr,
        win_probability_pct,
        strategic_importance,
        internal_notes,
        created_by,
        created_at,
        updated_at
      ) VALUES (
        $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16,
        $17, $18, $19, $20, $21, $22, NOW(), NOW()
      )
      RETURNING *;
    `;

    const result = await client.query(query, [
      customerId,
      leaderOwnerId,
      tenderName,
      tenderReferenceNo,
      tenderType,
      documentType,
      portalName,
      civilDefence,
      businessDomain,
      leadSubtype,
      soleConsortium,
      emdValue,
      emdExempted || false,
      emdMode,
      tenderDated,
      lastSubmissionDate,
      submissionMode,
      estimatedValueCr,
      winProbabilityPct || 50,
      strategicImportance || 'Medium',
      internalNotes,
      req.user?.id,
    ]);

    const leadId = result.rows[0].id;

    // Auto-create bidding process
    await client.query(`
      INSERT INTO bidding_process (
        tender_id,
        current_stage,
        go_no_go_decision,
        priority,
        health_status,
        created_by
      ) VALUES ($1, $2, $3, $4, $5, $6)
    `, [leadId, 'Pre-Qualification', 'Pending', 'Normal', 'Green', req.user?.id]);

    res.status(201).json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  } finally {
    client.release();
  }
};

export const getLeads = async (req, res) => {
  try {
    const { stage, outcome, domain, sector, limit = 50, offset = 0 } = req.query;

    let whereClause = 'WHERE t.is_deleted = FALSE';
    const params = [];
    let paramIndex = 1;

    if (stage) {
      whereClause += ` AND bp.current_stage = $${paramIndex}`;
      params.push(stage);
      paramIndex++;
    }

    if (outcome) {
      whereClause += ` AND t.outcome = $${paramIndex}`;
      params.push(outcome);
      paramIndex++;
    }

    if (domain) {
      whereClause += ` AND t.business_domain = $${paramIndex}`;
      params.push(domain);
      paramIndex++;
    }

    if (sector) {
      whereClause += ` AND t.civil_defence = $${paramIndex}`;
      params.push(sector);
      paramIndex++;
    }

    const query = `
      SELECT
        t.*,
        bp.id as bidding_id,
        bp.current_stage,
        bp.go_no_go_decision,
        bp.health_status,
        bp.days_in_current_stage,
        bp.is_overdue,
        c.company_name,
        c.contact_person,
        c.email
      FROM tenders t
      LEFT JOIN bidding_process bp ON t.id = bp.tender_id
      LEFT JOIN customers c ON t.customer_id = c.id
      ${whereClause}
      ORDER BY t.created_at DESC
      LIMIT $${paramIndex} OFFSET $${paramIndex + 1};
    `;

    params.push(limit, offset);
    const result = await pool.query(query, params);

    res.json({
      data: result.rows,
      total: result.rowCount,
      limit: parseInt(limit),
      offset: parseInt(offset),
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const getLeadById = async (req, res) => {
  try {
    const { id } = req.params;

    const query = `
      SELECT
        t.*,
        bp.id as bidding_id,
        bp.current_stage,
        bp.go_no_go_decision,
        bp.health_status,
        bp.days_in_current_stage,
        bp.is_overdue,
        c.id as customer_id,
        c.company_name,
        c.contact_person,
        c.designation,
        c.email,
        c.phone,
        c.address,
        c.city,
        c.state,
        c.pincode,
        u.username as lead_owner_name
      FROM tenders t
      LEFT JOIN bidding_process bp ON t.id = bp.tender_id
      LEFT JOIN customers c ON t.customer_id = c.id
      LEFT JOIN users u ON t.lead_owner_id = u.id
      WHERE t.id = $1 AND t.is_deleted = FALSE;
    `;

    const result = await pool.query(query, [id]);

    if (result.rowCount === 0) {
      return res.status(404).json({ error: 'Lead not found' });
    }

    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const updateLead = async (req, res) => {
  try {
    const { id } = req.params;
    const {
      tenderName,
      tenderReferenceNo,
      tenderType,
      documentType,
      estimatedValueCr,
      outcome,
      openClosed,
      orderWonValueCr,
      reasonForLosing,
    } = req.body;

    const query = `
      UPDATE tenders SET
        tender_name = COALESCE($2, tender_name),
        tender_reference_no = COALESCE($3, tender_reference_no),
        tender_type = COALESCE($4, tender_type),
        document_type = COALESCE($5, document_type),
        estimated_value_cr = COALESCE($6, estimated_value_cr),
        outcome = COALESCE($7, outcome),
        open_closed = COALESCE($8, open_closed),
        order_won_value_cr = COALESCE($9, order_won_value_cr),
        reason_for_losing = COALESCE($10, reason_for_losing),
        updated_at = NOW()
      WHERE id = $1 AND is_deleted = FALSE
      RETURNING *;
    `;

    const result = await pool.query(query, [
      id,
      tenderName,
      tenderReferenceNo,
      tenderType,
      documentType,
      estimatedValueCr,
      outcome,
      openClosed,
      orderWonValueCr,
      reasonForLosing,
    ]);

    if (result.rowCount === 0) {
      return res.status(404).json({ error: 'Lead not found' });
    }

    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const deleteLead = async (req, res) => {
  try {
    const { id } = req.params;

    const query = `
      UPDATE tenders SET
        is_deleted = TRUE,
        updated_at = NOW()
      WHERE id = $1
      RETURNING id;
    `;

    const result = await pool.query(query, [id]);

    if (result.rowCount === 0) {
      return res.status(404).json({ error: 'Lead not found' });
    }

    res.json({ message: 'Lead deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const getLeadsByStage = async (req, res) => {
  try {
    const { stage } = req.params;

    const query = `
      SELECT t.*, bp.current_stage, bp.health_status
      FROM tenders t
      LEFT JOIN bidding_process bp ON t.id = bp.tender_id
      WHERE bp.current_stage = $1 AND t.is_deleted = FALSE
      ORDER BY t.created_at DESC;
    `;

    const result = await pool.query(query, [stage]);
    res.json(result.rows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
