import pool from '../config/database.js';

// ============================================================================
// BIDDING PROCESS CONTROLLER
// ============================================================================

export const createBiddingProcess = async (req, res) => {
  try {
    const { id: tenderId } = req.params;
    const { currentStage, stageDueDate, stageOwnerId, goNoGoDecision } = req.body;

    const query = `
      INSERT INTO bidding_process (
        tender_id,
        current_stage,
        stage_due_date,
        stage_owner_id,
        go_no_go_decision,
        go_no_go_decided_by,
        go_no_go_decided_at,
        created_by
      ) VALUES ($1, $2, $3, $4, $5, $6, NOW(), $7)
      ON CONFLICT (tender_id) DO UPDATE SET
        current_stage = EXCLUDED.current_stage,
        updated_at = NOW()
      RETURNING *;
    `;

    const result = await pool.query(query, [
      tenderId,
      currentStage || 'Pre-Qualification',
      stageDueDate,
      stageOwnerId,
      goNoGoDecision || 'Pending',
      req.user?.id,
      req.user?.id,
    ]);

    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const getBiddingProcess = async (req, res) => {
  try {
    const { id: tenderId } = req.params;

    const query = `
      SELECT * FROM bidding_process
      WHERE tender_id = $1 AND is_deleted = FALSE;
    `;

    const result = await pool.query(query, [tenderId]);

    if (result.rowCount === 0) {
      return res.status(404).json({ error: 'Bidding process not found' });
    }

    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const updateStage = async (req, res) => {
  const client = await pool.connect();
  try {
    const { id: tenderId } = req.params;
    const { currentStage } = req.body;

    if (!currentStage) {
      return res.status(400).json({ error: 'Current stage is required' });
    }

    const validStages = [
      'Pre-Qualification',
      'Technical Qualification',
      'Commercial Qualification',
      'Evaluation',
      'Result',
      'Closed',
    ];

    if (!validStages.includes(currentStage)) {
      return res.status(400).json({ error: 'Invalid stage' });
    }

    await client.query('BEGIN');

    // Get previous stage from bidding_process
    const prevResult = await client.query(
      'SELECT current_stage, stage_entered_at FROM bidding_process WHERE tender_id = $1',
      [tenderId]
    );

    if (prevResult.rowCount === 0) {
      throw new Error('Bidding process not found');
    }

    const { current_stage: fromStage, stage_entered_at } = prevResult.rows[0];
    const daysSpent = Math.floor(
      (new Date() - new Date(stage_entered_at)) / (1000 * 60 * 60 * 24)
    );

    // Record stage history
    await client.query(
      `INSERT INTO stage_history (
        bidding_process_id, tender_id, from_stage, to_stage,
        days_spent, transitioned_by, created_at
      ) SELECT id, $2, $3, $4, $5, $6, NOW()
      FROM bidding_process WHERE tender_id = $2`,
      [tenderId, tenderId, fromStage, currentStage, daysSpent, req.user?.id]
    );

    // Update bidding process
    const updateResult = await client.query(
      `UPDATE bidding_process SET
        current_stage = $2,
        stage_entered_at = NOW(),
        stage_due_date = NULL,
        updated_at = NOW()
      WHERE tender_id = $1
      RETURNING *;`,
      [tenderId, currentStage]
    );

    await client.query('COMMIT');
    res.json(updateResult.rows[0]);
  } catch (error) {
    await client.query('ROLLBACK');
    res.status(500).json({ error: error.message });
  } finally {
    client.release();
  }
};

export const updateGoNoGo = async (req, res) => {
  try {
    const { id: tenderId } = req.params;
    const { goNoGoDecision, reason } = req.body;

    const query = `
      UPDATE bidding_process SET
        go_no_go_decision = $2,
        go_no_go_reason = $3,
        go_no_go_decided_by = $4,
        go_no_go_decided_at = NOW(),
        updated_at = NOW()
      WHERE tender_id = $1
      RETURNING *;
    `;

    const result = await pool.query(query, [
      tenderId,
      goNoGoDecision,
      reason,
      req.user?.id,
    ]);

    if (result.rowCount === 0) {
      return res.status(404).json({ error: 'Bidding process not found' });
    }

    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const getStageHistory = async (req, res) => {
  try {
    const { id: tenderId } = req.params;

    const query = `
      SELECT sh.* FROM stage_history sh
      INNER JOIN bidding_process bp ON sh.bidding_process_id = bp.id
      WHERE bp.tender_id = $1
      ORDER BY sh.transitioned_at DESC;
    `;

    const result = await pool.query(query, [tenderId]);
    res.json(result.rows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
